/*
 * Estas las realizaremos en el servicio. Como, introducir un elemento, modificar su precio,
eliminar un producto y mostrar los productos que tenemos con su precio (Utilizar
Hashmap). El HashMap tendrá de llave el nombre del producto y de valor el precio.
Realizar un menú para lograr todas las acciones previamente mencionadas.
 */
package servicio;

import entidad.Tienda;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

/**
 *
 * @author Usuario
 */
public class ServicioTienda {

    private HashMap<String, Integer> inventario = new HashMap<>();
    ;
    private Scanner leer = new Scanner(System.in).useDelimiter("\n");

    public void crearProducto() {

        Tienda nw = new Tienda();
        System.out.println("Ingrese el nombre del producto");
        nw.setProducto(leer.next());
        System.out.println("Ingrese el valor");
        nw.setPrecio(leer.nextInt());
        inventario.put(nw.getProducto(), nw.getPrecio());

    }

    public void llenarInventario() {

        do {
            crearProducto();
            System.out.println("desea agregar otro producto? S/N");

        } while (leer.next().equalsIgnoreCase("s"));

    }

    public void mostrar() {

        for (Map.Entry<String, Integer> entry : inventario.entrySet()) {
            String key = entry.getKey();
            Integer value = entry.getValue();

            System.out.println("el producto es: " + key + " su precio es: " + value);

        }

    }

    public void modificarPrecio() {
        
        
        System.out.println("Ingrese el nombre de producto al cual se le va a modificar el precio");
        String llave = leer.next();
        if (inventario.containsKey(llave)) {
            System.out.println("Ingrese el nuevo precio: ");
            inventario.put(llave, leer.nextInt());
        } else {
            System.out.println("No existe el producto");
        }
       
    }
    
    public void eliminar(){
        
        System.out.println("Ingrese el nombre de producto al cual va a eliminar");
        String llave = leer.next();
        if (inventario.containsKey(llave)) {
            inventario.remove(llave);
        } else {
            System.out.println("No existe el producto");
        }
        
    }
    
    public void menu(){
        
        boolean salir;
        
        do {
            salir=false;
             System.out.println("\nDigite una opción\n"
                + "1. introducir un nuevo producto\n"
                + "2. modificar precio de un producto\n"
                + "3. eliminar un producto\n"
                + "4. mostrar inventario\n"
                + "5. salir");
        
        switch (leer.nextInt()) {
            case 1:
                llenarInventario();
                break;
            case 2:
                modificarPrecio();
                break;
            case 3:
                eliminar();
                break;  
            case 4:
                mostrar();
                break;  
            case 5:
                salir=true;
                break;    
            default:
                System.out.println("la opción no es válida");
        }
        } while (!salir);
        
       
        
        
    }

}
