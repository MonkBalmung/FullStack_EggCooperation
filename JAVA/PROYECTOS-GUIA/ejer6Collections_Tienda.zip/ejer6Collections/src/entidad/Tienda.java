/*
 * Se necesita una aplicación para una tienda en la cual queremos almacenar los distintos
productos que venderemos y el precio que tendrán. Además, se necesita que la
aplicación cuente con las funciones básicas.

 */
package entidad;

/**
 *
 * @author Usuario
 */
public class Tienda {
    
    private Integer precio;
    private String producto;

    public Tienda() {
    }

    public Tienda(Integer precio, String producto) {
        this.precio = precio;
        this.producto = producto;
    }

    public Integer getPrecio() {
        return precio;
    }

    public void setPrecio(Integer precio) {
        this.precio = precio;
    }

    public String getProducto() {
        return producto;
    }

    public void setProducto(String producto) {
        this.producto = producto;
    }

    @Override
    public String toString() {
        return "Tienda{" + "precio=" + precio + ", producto=" + producto + '}';
    }
    
    
    
}
