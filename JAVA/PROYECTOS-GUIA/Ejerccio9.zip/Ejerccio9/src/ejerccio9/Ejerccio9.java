/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejerccio9;

/**
 *
 * @author luisc
 */
public class Ejerccio9 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ServicioCalcula cal = new ServicioCalcula();
        cal.LeerNumeros();
        System.out.println("retornar cuál de los dos atributos tiene el mayor valor: "+cal.devolverMayor());
        
        System.out.println("retornar  la potencia del mayor valor de la clase: "+cal.calcularPotencia());
        
        System.out.println("retornar  la raíz cuadrada del menor: "+cal.calcularRaiz());
        
    }
    
}
