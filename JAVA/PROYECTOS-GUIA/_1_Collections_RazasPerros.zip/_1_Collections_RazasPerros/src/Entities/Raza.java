/*
Diseñar un programa que lea y guarde razas de perros en un ArrayList de tipo String. 
 */
package Entities;

//@author MENESES-FLOREZ
public class Raza
{
    //Atributes
    private String nombreRaza;
    
    //Contructors

    public Raza() {}

    public Raza(String nombreRaza) {
        this.nombreRaza = nombreRaza;
    }
    
    //Getter % Setters

    public String getNombreRaza() {
        return nombreRaza;
    }

    public void setNombreRaza(String nombreRaza) {
        this.nombreRaza = nombreRaza;
    }
    
    //ToString

    @Override
    public String toString() {
        return "Raza{" + "nombreRaza: " + nombreRaza + '}';
    }
}
