/*
El programa pedirá una raza de perro en un bucle, el mismo se guardará en la lista y
después se le preguntará al usuario si quiere guardar otro perro o si quiere salir. Si decide
salir, se mostrará todos los perros guardados en el ArrayList.
 */
package Services;

//@author MENESES-FLOREZ

import Entities.Raza;
import java.util.ArrayList;
import java.util.Scanner;

public class RazaService
{
    private Scanner input = new Scanner(System.in).useDelimiter("\n");
    
    private ArrayList<Raza> listaRazaPerros = new ArrayList();
    
    private Raza razaPerro = new Raza();
    
    public void crearRaza()
    {
        //Raza razaPerro = new Raza();
        
        System.out.println("Ingrese la raza del perro: ");
        razaPerro.setNombreRaza(input.next());  
        
        //return razaPerro;
    }
    
    public void llenarLista()
    {
        boolean ingresar = true;
        String opcion;
        
        while (ingresar) {
            this.crearRaza();
            listaRazaPerros.add(new Raza(razaPerro.getNombreRaza()));   
            System.out.println("¿Desea ingresar otra raza? S/N");
            opcion = input.next().toUpperCase();
            ingresar = opcion.equals("S"); // Esta expresion reemplaza en sintaxis al IF
        }
       
    }
    
    public void mostrarListaRazas()
    {
        System.out.println(listaRazaPerros);
    }
    
    
}
