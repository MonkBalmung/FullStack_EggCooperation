/*
 */
package Enums;

//@author MENESES-FLOREZ */


public enum MascotaTamanio
{
    GRANDE, MEDIANO, PEQUEÑO;
}
