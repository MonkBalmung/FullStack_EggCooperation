/*

 */
package Enums;

//@author MENESES-FLOREZ */


public enum TiendaInventario
{
    PERRO, GATO, AVE, PEZ;
}
