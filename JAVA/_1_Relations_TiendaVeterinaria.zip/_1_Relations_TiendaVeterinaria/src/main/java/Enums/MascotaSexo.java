/*
 */
package Enums;

//@author MENESES-FLOREZ */


public enum MascotaSexo
{
    MACHO, HEMBRA;
}
